import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Calculator from './components/Calculator';
import CalculationHistory from './components/CalculationHistory';
import BlogSection from './components/BlogSection';
import Footer from './components/Footer';
import GSTCalculatorPage from './pages/GSTCalculatorPage';
import { useLocalStorage } from './hooks/useLocalStorage';
import type { Calculation } from './types';

function HomePage() {
  const [calculations, setCalculations] = useLocalStorage<Calculation[]>('calculations', []);
  const [showHistory, setShowHistory] = useState(false);

  const handleNewCalculation = (calculation: Calculation) => {
    setCalculations(prev => [...prev, calculation]);
  };

  const clearHistory = () => {
    setCalculations([]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-blue-900 transition-colors duration-300">
      <Header currentPage="percentage" />
      
      <main>
        <Calculator onCalculation={handleNewCalculation} />
        
        {calculations.length > 0 && (
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
            <div className="text-center">
              <button
                onClick={() => setShowHistory(!showHistory)}
                className="px-6 py-3 bg-white/70 dark:bg-gray-800/70 backdrop-blur-lg border border-gray-200 dark:border-gray-700 rounded-xl font-medium text-gray-700 dark:text-gray-300 hover:bg-white dark:hover:bg-gray-800 transition-all duration-200 shadow-lg hover:shadow-xl hover:scale-105"
              >
                {showHistory ? 'Hide History' : `View History (${calculations.length})`}
              </button>
            </div>
          </div>
        )}

        {showHistory && (
          <CalculationHistory 
            calculations={calculations} 
            onClearHistory={clearHistory}
          />
        )}

        <BlogSection />
      </main>

      <Footer />
    </div>
  );
}

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/gst" element={<GSTCalculatorPage />} />
      </Routes>
    </Router>
  );
}

export default App;