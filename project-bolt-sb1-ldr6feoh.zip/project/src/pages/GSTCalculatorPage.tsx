import React, { useState } from 'react';
import Header from '../components/Header';
import GSTCalculator from '../components/GSTCalculator';
import GSTCalculationHistory from '../components/GSTCalculationHistory';
import Footer from '../components/Footer';
import { useLocalStorage } from '../hooks/useLocalStorage';
import type { GSTCalculation } from '../types';

const GSTCalculatorPage: React.FC = () => {
  const [gstCalculations, setGstCalculations] = useLocalStorage<GSTCalculation[]>('gst-calculations', []);
  const [showHistory, setShowHistory] = useState(false);

  const handleNewCalculation = (calculation: GSTCalculation) => {
    setGstCalculations(prev => [...prev, calculation]);
  };

  const clearHistory = () => {
    setGstCalculations([]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-green-900 transition-colors duration-300">
      <Header />
      
      <main>
        <GSTCalculator onCalculation={handleNewCalculation} />
        
        {gstCalculations.length > 0 && (
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
            <div className="text-center">
              <button
                onClick={() => setShowHistory(!showHistory)}
                className="px-6 py-3 bg-white/70 dark:bg-gray-800/70 backdrop-blur-lg border border-gray-200 dark:border-gray-700 rounded-xl font-medium text-gray-700 dark:text-gray-300 hover:bg-white dark:hover:bg-gray-800 transition-all duration-200 shadow-lg hover:shadow-xl hover:scale-105"
              >
                {showHistory ? 'Hide History' : `View History (${gstCalculations.length})`}
              </button>
            </div>
          </div>
        )}

        {showHistory && (
          <GSTCalculationHistory 
            calculations={gstCalculations} 
            onClearHistory={clearHistory}
          />
        )}
      </main>

      <Footer />
    </div>
  );
};

export default GSTCalculatorPage;