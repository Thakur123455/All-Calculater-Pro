import React, { useState, useEffect } from 'react';
import { Copy, Share2, RotateCcw, TrendingUp, TrendingDown, Percent } from 'lucide-react';
import { 
  calculatePercentageOf, 
  calculateWhatPercent, 
  calculatePercentageIncrease, 
  calculatePercentageDecrease,
  formatNumber,
  validateInput
} from '../utils/calculations';
import type { Calculation } from '../types';

interface CalculatorProps {
  onCalculation: (calculation: Calculation) => void;
}

type CalculationType = 'percentage-of' | 'what-percent' | 'increase-decrease';

const Calculator: React.FC<CalculatorProps> = ({ onCalculation }) => {
  const [calculationType, setCalculationType] = useState<CalculationType>('percentage-of');
  const [input1, setInput1] = useState('');
  const [input2, setInput2] = useState('');
  const [result, setResult] = useState<number | null>(null);
  const [errors, setErrors] = useState<{ input1?: string; input2?: string }>({});
  const [isIncreaseMode, setIsIncreaseMode] = useState(true);

  const calculateResult = () => {
    const validation1 = validateInput(input1);
    const validation2 = validateInput(input2);
    
    const newErrors: { input1?: string; input2?: string } = {};
    if (!validation1.isValid) newErrors.input1 = validation1.error;
    if (!validation2.isValid) newErrors.input2 = validation2.error;
    
    setErrors(newErrors);
    
    if (!validation1.isValid || !validation2.isValid) {
      setResult(null);
      return;
    }

    const num1 = parseFloat(input1);
    const num2 = parseFloat(input2);
    let calculatedResult: number;
    let formula: string;

    switch (calculationType) {
      case 'percentage-of':
        calculatedResult = calculatePercentageOf(num1, num2);
        formula = `${num1}% of ${num2} = ${formatNumber(calculatedResult)}`;
        break;
      case 'what-percent':
        calculatedResult = calculateWhatPercent(num1, num2);
        formula = `${num1} is ${formatNumber(calculatedResult)}% of ${num2}`;
        break;
      case 'increase-decrease':
        calculatedResult = isIncreaseMode 
          ? calculatePercentageIncrease(num1, num2)
          : calculatePercentageDecrease(num1, num2);
        formula = `${num1} ${isIncreaseMode ? 'increased' : 'decreased'} by ${num2}% = ${formatNumber(calculatedResult)}`;
        break;
    }

    setResult(calculatedResult);

    const calculation: Calculation = {
      id: Date.now().toString(),
      type: calculationType,
      input1: num1,
      input2: num2,
      result: calculatedResult,
      timestamp: new Date(),
      formula
    };

    onCalculation(calculation);
  };

  useEffect(() => {
    if (input1 && input2) {
      calculateResult();
    } else {
      setResult(null);
    }
  }, [input1, input2, calculationType, isIncreaseMode]);

  const copyResult = async () => {
    if (result !== null) {
      try {
        await navigator.clipboard.writeText(formatNumber(result));
        // You could add a toast notification here
      } catch (err) {
        console.error('Failed to copy result:', err);
      }
    }
  };

  const shareResult = async () => {
    if (result !== null && navigator.share) {
      try {
        await navigator.share({
          title: 'Percentage Calculator Result',
          text: `Result: ${formatNumber(result)}`,
          url: window.location.href
        });
      } catch (err) {
        console.error('Failed to share result:', err);
      }
    }
  };

  const clearInputs = () => {
    setInput1('');
    setInput2('');
    setResult(null);
    setErrors({});
  };

  const getCalculationTitle = () => {
    switch (calculationType) {
      case 'percentage-of':
        return 'What is X% of Y?';
      case 'what-percent':
        return 'X is what percent of Y?';
      case 'increase-decrease':
        return isIncreaseMode ? 'Increase by X%' : 'Decrease by X%';
    }
  };

  const getInputLabels = () => {
    switch (calculationType) {
      case 'percentage-of':
        return ['Percentage (%)', 'Value'];
      case 'what-percent':
        return ['Value', 'Total'];
      case 'increase-decrease':
        return ['Original Value', 'Percentage (%)'];
    }
  };

  const [label1, label2] = getInputLabels();

  return (
    <div id="calculator" className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <div className="text-center mb-12">
        <h2 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-teal-600 bg-clip-text text-transparent mb-4">
          Percentage Calculator
        </h2>
        <p className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
          Calculate percentages instantly with our modern, user-friendly tool. Get real-time results as you type.
        </p>
      </div>

      <div className="bg-white/70 dark:bg-gray-800/70 backdrop-blur-lg rounded-3xl shadow-2xl border border-gray-200 dark:border-gray-700 p-8 md:p-12">
        {/* Calculation Type Selector */}
        <div className="mb-8">
          <div className="flex flex-wrap gap-2 md:gap-4 justify-center">
            <button
              onClick={() => setCalculationType('percentage-of')}
              className={`px-4 py-3 rounded-xl font-medium transition-all duration-300 flex items-center space-x-2 ${
                calculationType === 'percentage-of'
                  ? 'bg-blue-500 text-white shadow-lg scale-105'
                  : 'bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300'
              }`}
            >
              <Percent className="h-4 w-4" />
              <span className="text-sm md:text-base">X% of Y</span>
            </button>
            <button
              onClick={() => setCalculationType('what-percent')}
              className={`px-4 py-3 rounded-xl font-medium transition-all duration-300 flex items-center space-x-2 ${
                calculationType === 'what-percent'
                  ? 'bg-blue-500 text-white shadow-lg scale-105'
                  : 'bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300'
              }`}
            >
              <Percent className="h-4 w-4" />
              <span className="text-sm md:text-base">X is what % of Y</span>
            </button>
            <button
              onClick={() => setCalculationType('increase-decrease')}
              className={`px-4 py-3 rounded-xl font-medium transition-all duration-300 flex items-center space-x-2 ${
                calculationType === 'increase-decrease'
                  ? 'bg-blue-500 text-white shadow-lg scale-105'
                  : 'bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300'
              }`}
            >
              {isIncreaseMode ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
              <span className="text-sm md:text-base">Increase/Decrease</span>
            </button>
          </div>

          {calculationType === 'increase-decrease' && (
            <div className="flex justify-center mt-4">
              <div className="bg-gray-100 dark:bg-gray-700 rounded-lg p-1 flex">
                <button
                  onClick={() => setIsIncreaseMode(true)}
                  className={`px-4 py-2 rounded-md font-medium transition-all duration-200 flex items-center space-x-2 ${
                    isIncreaseMode
                      ? 'bg-green-500 text-white shadow-md'
                      : 'text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200'
                  }`}
                >
                  <TrendingUp className="h-4 w-4" />
                  <span>Increase</span>
                </button>
                <button
                  onClick={() => setIsIncreaseMode(false)}
                  className={`px-4 py-2 rounded-md font-medium transition-all duration-200 flex items-center space-x-2 ${
                    !isIncreaseMode
                      ? 'bg-red-500 text-white shadow-md'
                      : 'text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200'
                  }`}
                >
                  <TrendingDown className="h-4 w-4" />
                  <span>Decrease</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Calculation Title */}
        <div className="text-center mb-8">
          <h3 className="text-2xl font-semibold text-gray-800 dark:text-gray-200">
            {getCalculationTitle()}
          </h3>
        </div>

        {/* Input Fields */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {label1}
            </label>
            <input
              type="number"
              value={input1}
              onChange={(e) => setInput1(e.target.value)}
              className={`w-full px-4 py-4 text-lg rounded-xl border-2 transition-all duration-200 bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-4 focus:ring-blue-500/20 ${
                errors.input1
                  ? 'border-red-500 focus:border-red-500'
                  : 'border-gray-200 dark:border-gray-600 focus:border-blue-500'
              }`}
              placeholder={`Enter ${label1.toLowerCase()}`}
            />
            {errors.input1 && (
              <p className="mt-2 text-sm text-red-600 dark:text-red-400">{errors.input1}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {label2}
            </label>
            <input
              type="number"
              value={input2}
              onChange={(e) => setInput2(e.target.value)}
              className={`w-full px-4 py-4 text-lg rounded-xl border-2 transition-all duration-200 bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-4 focus:ring-blue-500/20 ${
                errors.input2
                  ? 'border-red-500 focus:border-red-500'
                  : 'border-gray-200 dark:border-gray-600 focus:border-blue-500'
              }`}
              placeholder={`Enter ${label2.toLowerCase()}`}
            />
            {errors.input2 && (
              <p className="mt-2 text-sm text-red-600 dark:text-red-400">{errors.input2}</p>
            )}
          </div>
        </div>

        {/* Result Display */}
        {result !== null && (
          <div className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 rounded-2xl p-6 mb-6 border border-blue-200 dark:border-blue-700/50">
            <div className="text-center">
              <p className="text-lg text-gray-600 dark:text-gray-400 mb-2">Result</p>
              <p className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-4">
                {formatNumber(result)}
              </p>
              <div className="flex flex-wrap justify-center gap-3">
                <button
                  onClick={copyResult}
                  className="px-4 py-2 bg-white dark:bg-gray-800 rounded-lg shadow-md hover:shadow-lg transition-all duration-200 flex items-center space-x-2 text-gray-700 dark:text-gray-300 hover:scale-105"
                >
                  <Copy className="h-4 w-4" />
                  <span>Copy</span>
                </button>
                {navigator.share && (
                  <button
                    onClick={shareResult}
                    className="px-4 py-2 bg-white dark:bg-gray-800 rounded-lg shadow-md hover:shadow-lg transition-all duration-200 flex items-center space-x-2 text-gray-700 dark:text-gray-300 hover:scale-105"
                  >
                    <Share2 className="h-4 w-4" />
                    <span>Share</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Clear Button */}
        <div className="text-center">
          <button
            onClick={clearInputs}
            className="px-6 py-3 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-xl font-medium text-gray-700 dark:text-gray-300 transition-all duration-200 flex items-center space-x-2 mx-auto hover:scale-105"
          >
            <RotateCcw className="h-4 w-4" />
            <span>Clear All</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Calculator;