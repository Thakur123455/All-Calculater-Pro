import React, { useState, useEffect } from 'react';
import { Copy, Share2, RotateCcw, Plus, Minus, Calculator, Download, FileText } from 'lucide-react';
import { 
  addGST, 
  removeGST, 
  formatCurrency, 
  formatNumber,
  validateGSTInput,
  validateGSTRate
} from '../utils/gstCalculations';
import type { GSTCalculation } from '../types';

interface GSTCalculatorProps {
  onCalculation: (calculation: GSTCalculation) => void;
}

type CalculationType = 'add-gst' | 'remove-gst';

const predefinedRates = [5, 12, 18, 28];

const GSTCalculator: React.FC<GSTCalculatorProps> = ({ onCalculation }) => {
  const [calculationType, setCalculationType] = useState<CalculationType>('add-gst');
  const [amount, setAmount] = useState('');
  const [gstRate, setGstRate] = useState(18);
  const [customRate, setCustomRate] = useState('');
  const [useCustomRate, setUseCustomRate] = useState(false);
  const [result, setResult] = useState<{ baseAmount: number; gstAmount: number; totalAmount: number } | null>(null);
  const [errors, setErrors] = useState<{ amount?: string; gstRate?: string }>({});

  const calculateGST = () => {
    const amountValidation = validateGSTInput(amount);
    const currentGSTRate = useCustomRate ? parseFloat(customRate) : gstRate;
    const rateValidation = validateGSTRate(currentGSTRate);
    
    const newErrors: { amount?: string; gstRate?: string } = {};
    if (!amountValidation.isValid) newErrors.amount = amountValidation.error;
    if (!rateValidation.isValid) newErrors.gstRate = rateValidation.error;
    if (useCustomRate && !validateGSTInput(customRate).isValid) {
      newErrors.gstRate = 'Please enter a valid GST rate';
    }
    
    setErrors(newErrors);
    
    if (!amountValidation.isValid || !rateValidation.isValid || (useCustomRate && !validateGSTInput(customRate).isValid)) {
      setResult(null);
      return;
    }

    const inputAmount = parseFloat(amount);
    let calculatedResult: { baseAmount: number; gstAmount: number; totalAmount: number };
    let formula: string;

    if (calculationType === 'add-gst') {
      calculatedResult = addGST(inputAmount, currentGSTRate);
      formula = `₹${formatNumber(inputAmount)} + ${currentGSTRate}% GST = ₹${formatNumber(calculatedResult.totalAmount)}`;
    } else {
      calculatedResult = removeGST(inputAmount, currentGSTRate);
      formula = `₹${formatNumber(inputAmount)} - ${currentGSTRate}% GST = ₹${formatNumber(calculatedResult.baseAmount)} (Base)`;
    }

    setResult(calculatedResult);

    const calculation: GSTCalculation = {
      id: Date.now().toString(),
      type: calculationType,
      baseAmount: calculatedResult.baseAmount,
      gstRate: currentGSTRate,
      gstAmount: calculatedResult.gstAmount,
      totalAmount: calculatedResult.totalAmount,
      timestamp: new Date(),
      formula
    };

    onCalculation(calculation);
  };

  useEffect(() => {
    if (amount && (useCustomRate ? customRate : gstRate)) {
      calculateGST();
    } else {
      setResult(null);
    }
  }, [amount, gstRate, customRate, useCustomRate, calculationType]);

  const copyResult = async () => {
    if (result) {
      const resultText = calculationType === 'add-gst' 
        ? `Total Amount: ${formatCurrency(result.totalAmount)}`
        : `Base Amount: ${formatCurrency(result.baseAmount)}`;
      
      try {
        await navigator.clipboard.writeText(resultText);
      } catch (err) {
        console.error('Failed to copy result:', err);
      }
    }
  };

  const shareResult = async () => {
    if (result && navigator.share) {
      const resultText = calculationType === 'add-gst' 
        ? `GST Calculation: ${formatCurrency(result.totalAmount)} (including ${useCustomRate ? customRate : gstRate}% GST)`
        : `GST Calculation: ${formatCurrency(result.baseAmount)} (excluding ${useCustomRate ? customRate : gstRate}% GST)`;
      
      try {
        await navigator.share({
          title: 'GST Calculator Result',
          text: resultText,
          url: window.location.href
        });
      } catch (err) {
        console.error('Failed to share result:', err);
      }
    }
  };

  const downloadPDF = () => {
    if (result) {
      // Create a simple text representation for download
      const content = `
GST Calculation Report
=====================

Calculation Type: ${calculationType === 'add-gst' ? 'Add GST (Exclusive → Inclusive)' : 'Remove GST (Inclusive → Exclusive)'}
GST Rate: ${useCustomRate ? customRate : gstRate}%

Base Amount: ${formatCurrency(result.baseAmount)}
GST Amount: ${formatCurrency(result.gstAmount)}
Total Amount: ${formatCurrency(result.totalAmount)}

Generated on: ${new Date().toLocaleString()}
      `;
      
      const blob = new Blob([content], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `gst-calculation-${Date.now()}.txt`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  };

  const clearInputs = () => {
    setAmount('');
    setCustomRate('');
    setResult(null);
    setErrors({});
  };

  const currentGSTRate = useCustomRate ? parseFloat(customRate) || 0 : gstRate;

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-green-600 via-blue-600 to-purple-600 bg-clip-text text-transparent mb-4">
          GST Calculator
        </h1>
        <p className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
          Calculate Goods and Services Tax instantly. Add or remove GST with real-time results and detailed breakdowns.
        </p>
      </div>

      <div className="bg-white/70 dark:bg-gray-800/70 backdrop-blur-lg rounded-3xl shadow-2xl border border-gray-200 dark:border-gray-700 p-8 md:p-12">
        {/* Calculation Type Selector */}
        <div className="mb-8">
          <div className="flex flex-wrap gap-4 justify-center">
            <button
              onClick={() => setCalculationType('add-gst')}
              className={`px-6 py-3 rounded-xl font-medium transition-all duration-300 flex items-center space-x-2 ${
                calculationType === 'add-gst'
                  ? 'bg-green-500 text-white shadow-lg scale-105'
                  : 'bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300'
              }`}
            >
              <Plus className="h-4 w-4" />
              <span>Add GST (Exclusive → Inclusive)</span>
            </button>
            <button
              onClick={() => setCalculationType('remove-gst')}
              className={`px-6 py-3 rounded-xl font-medium transition-all duration-300 flex items-center space-x-2 ${
                calculationType === 'remove-gst'
                  ? 'bg-red-500 text-white shadow-lg scale-105'
                  : 'bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300'
              }`}
            >
              <Minus className="h-4 w-4" />
              <span>Remove GST (Inclusive → Exclusive)</span>
            </button>
          </div>
        </div>

        {/* Calculation Title */}
        <div className="text-center mb-8">
          <h3 className="text-2xl font-semibold text-gray-800 dark:text-gray-200">
            {calculationType === 'add-gst' 
              ? 'Calculate Total Amount with GST' 
              : 'Calculate Base Amount without GST'
            }
          </h3>
        </div>

        {/* Input Fields */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {calculationType === 'add-gst' ? 'Amount (Excluding GST)' : 'Amount (Including GST)'}
            </label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 dark:text-gray-400">₹</span>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className={`w-full pl-8 pr-4 py-4 text-lg rounded-xl border-2 transition-all duration-200 bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-4 focus:ring-green-500/20 ${
                  errors.amount
                    ? 'border-red-500 focus:border-red-500'
                    : 'border-gray-200 dark:border-gray-600 focus:border-green-500'
                }`}
                placeholder="Enter amount"
              />
            </div>
            {errors.amount && (
              <p className="mt-2 text-sm text-red-600 dark:text-red-400">{errors.amount}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              GST Rate
            </label>
            
            {!useCustomRate ? (
              <div className="space-y-3">
                <div className="grid grid-cols-4 gap-2">
                  {predefinedRates.map((rate) => (
                    <button
                      key={rate}
                      onClick={() => setGstRate(rate)}
                      className={`py-3 px-2 rounded-lg font-medium transition-all duration-200 ${
                        gstRate === rate
                          ? 'bg-green-500 text-white shadow-md scale-105'
                          : 'bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300'
                      }`}
                    >
                      {rate}%
                    </button>
                  ))}
                </div>
                <button
                  onClick={() => setUseCustomRate(true)}
                  className="w-full py-2 text-sm text-green-600 dark:text-green-400 hover:text-green-700 dark:hover:text-green-300 transition-colors duration-200"
                >
                  Use Custom Rate
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="relative">
                  <input
                    type="number"
                    value={customRate}
                    onChange={(e) => setCustomRate(e.target.value)}
                    className={`w-full pr-8 pl-4 py-4 text-lg rounded-xl border-2 transition-all duration-200 bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-4 focus:ring-green-500/20 ${
                      errors.gstRate
                        ? 'border-red-500 focus:border-red-500'
                        : 'border-gray-200 dark:border-gray-600 focus:border-green-500'
                    }`}
                    placeholder="Enter custom rate"
                    min="0"
                    max="100"
                    step="0.01"
                  />
                  <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 dark:text-gray-400">%</span>
                </div>
                <button
                  onClick={() => {
                    setUseCustomRate(false);
                    setCustomRate('');
                  }}
                  className="w-full py-2 text-sm text-gray-600 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 transition-colors duration-200"
                >
                  Use Predefined Rates
                </button>
              </div>
            )}
            
            {errors.gstRate && (
              <p className="mt-2 text-sm text-red-600 dark:text-red-400">{errors.gstRate}</p>
            )}
          </div>
        </div>

        {/* Result Display */}
        {result && (
          <div className="bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-900/20 dark:to-blue-900/20 rounded-2xl p-6 mb-6 border border-green-200 dark:border-green-700/50">
            <div className="text-center mb-6">
              <h4 className="text-lg font-semibold text-gray-700 dark:text-gray-300 mb-4">GST Calculation Breakdown</h4>
              
              <div className="grid md:grid-cols-3 gap-4">
                <div className="bg-white/70 dark:bg-gray-800/70 rounded-xl p-4">
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Base Amount</p>
                  <p className="text-xl font-bold text-gray-900 dark:text-gray-100">
                    {formatCurrency(result.baseAmount)}
                  </p>
                </div>
                
                <div className="bg-white/70 dark:bg-gray-800/70 rounded-xl p-4">
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">GST Amount ({currentGSTRate}%)</p>
                  <p className="text-xl font-bold text-green-600 dark:text-green-400">
                    {formatCurrency(result.gstAmount)}
                  </p>
                </div>
                
                <div className="bg-white/70 dark:bg-gray-800/70 rounded-xl p-4">
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Total Amount</p>
                  <p className="text-2xl font-bold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
                    {formatCurrency(result.totalAmount)}
                  </p>
                </div>
              </div>
              
              <div className="flex flex-wrap justify-center gap-3 mt-6">
                <button
                  onClick={copyResult}
                  className="px-4 py-2 bg-white dark:bg-gray-800 rounded-lg shadow-md hover:shadow-lg transition-all duration-200 flex items-center space-x-2 text-gray-700 dark:text-gray-300 hover:scale-105"
                >
                  <Copy className="h-4 w-4" />
                  <span>Copy</span>
                </button>
                
                {navigator.share && (
                  <button
                    onClick={shareResult}
                    className="px-4 py-2 bg-white dark:bg-gray-800 rounded-lg shadow-md hover:shadow-lg transition-all duration-200 flex items-center space-x-2 text-gray-700 dark:text-gray-300 hover:scale-105"
                  >
                    <Share2 className="h-4 w-4" />
                    <span>Share</span>
                  </button>
                )}
                
                <button
                  onClick={downloadPDF}
                  className="px-4 py-2 bg-white dark:bg-gray-800 rounded-lg shadow-md hover:shadow-lg transition-all duration-200 flex items-center space-x-2 text-gray-700 dark:text-gray-300 hover:scale-105"
                >
                  <Download className="h-4 w-4" />
                  <span>Download</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Clear Button */}
        <div className="text-center">
          <button
            onClick={clearInputs}
            className="px-6 py-3 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-xl font-medium text-gray-700 dark:text-gray-300 transition-all duration-200 flex items-center space-x-2 mx-auto hover:scale-105"
          >
            <RotateCcw className="h-4 w-4" />
            <span>Clear All</span>
          </button>
        </div>
      </div>

      {/* GST Information Section */}
      <div className="mt-16 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 rounded-2xl p-8 border border-blue-200 dark:border-blue-700/50">
        <div className="text-center mb-8">
          <h3 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-4">
            Understanding GST Rates in India
          </h3>
          <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
            Goods and Services Tax (GST) is a comprehensive indirect tax levied on the supply of goods and services in India.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { rate: '5%', items: 'Essential items like food grains, milk, vegetables' },
            { rate: '12%', items: 'Processed foods, medicines, textiles' },
            { rate: '18%', items: 'Most goods and services, electronics, restaurants' },
            { rate: '28%', items: 'Luxury items, automobiles, tobacco products' }
          ].map((item, index) => (
            <div key={index} className="bg-white/70 dark:bg-gray-800/70 rounded-xl p-6 text-center">
              <div className="text-2xl font-bold text-green-600 dark:text-green-400 mb-2">
                {item.rate}
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                {item.items}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default GSTCalculator;