export const addGST = (amount: number, gstRate: number): { baseAmount: number; gstAmount: number; totalAmount: number } => {
  const baseAmount = amount;
  const gstAmount = (amount * gstRate) / 100;
  const totalAmount = amount + gstAmount;
  
  return {
    baseAmount,
    gstAmount,
    totalAmount
  };
};

export const removeGST = (amount: number, gstRate: number): { baseAmount: number; gstAmount: number; totalAmount: number } => {
  const totalAmount = amount;
  const baseAmount = amount / (1 + gstRate / 100);
  const gstAmount = amount - baseAmount;
  
  return {
    baseAmount,
    gstAmount,
    totalAmount
  };
};

export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(amount);
};

export const formatNumber = (num: number): string => {
  if (Number.isInteger(num)) {
    return num.toString();
  }
  return parseFloat(num.toFixed(2)).toString();
};

export const validateGSTInput = (value: string): { isValid: boolean; error?: string } => {
  if (value.trim() === '') {
    return { isValid: false, error: 'This field is required' };
  }
  
  const num = parseFloat(value);
  if (isNaN(num)) {
    return { isValid: false, error: 'Please enter a valid number' };
  }
  
  if (num < 0) {
    return { isValid: false, error: 'Amount cannot be negative' };
  }
  
  return { isValid: true };
};

export const validateGSTRate = (value: number): { isValid: boolean; error?: string } => {
  if (value < 0 || value > 100) {
    return { isValid: false, error: 'GST rate must be between 0% and 100%' };
  }
  
  return { isValid: true };
};